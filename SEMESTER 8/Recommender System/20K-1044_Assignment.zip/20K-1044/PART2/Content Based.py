import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

data_df1 = pd.read_csv('movies.csv')

data_df2 = pd.read_csv('ratings.csv')  


data_df3 = pd.read_csv('tags.csv')

merged_df1 = pd.merge(data_df1, data_df3, on='movieId', how='left')  

merged_df2 = pd.merge(merged_df1, data_df2, on='movieId', how='left')

merged_df2['tag'] = merged_df2['tag'].fillna('')
merged_df2['features'] = merged_df2['genres'].str.replace('|', ' ') + ' ' + merged_df2['tag']

tfidf_vectorizer = TfidfVectorizer(stop_words='english')    



tfidf_matrix = tfidf_vectorizer.fit_transform(merged_df2['features'])

def retrieve_movie_id(title):
    return data_df1[data_df1['title'].str.contains(title, case=False)].iloc[0]['movieId']


print("Enter your 3 favorite movies Name:")

favs_titles = [input(f"Movie {i+1}: ") for i in range(3)]

favs_ids = [retrieve_movie_id(title) for title in favs_titles]

favs_indices = [merged_df2[merged_df2['movieId'] == id].index[0] for id in favs_ids]

user_profile = np.mean(tfidf_matrix[favs_indices], axis=0)

user_profile_arr = np.array(user_profile).reshape(1, -1)

cosine_sim_scores = cosine_similarity(user_profile_arr, tfidf_matrix)
movie_indices = np.argsort(cosine_sim_scores.flatten())[::-1]



user_rated_movies = data_df2['movieId'].unique()
recommended_movie_ids = [idx for idx in movie_indices if merged_df2.iloc[idx]['movieId'] not in user_rated_movies][:5]

print("\nTop 5 recommended movies for you:")

for idx in recommended_movie_ids:


    print(data_df1[data_df1['movieId'] == merged_df2.iloc[idx]['movieId']]['title'].iloc[0])