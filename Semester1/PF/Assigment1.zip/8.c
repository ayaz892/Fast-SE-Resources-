
// ASSIGNMENT=1
//  SE-SEC 2A
// ID=20K-1044
// MUHAMMAD AYAZ

#include <stdio.h>
int main()
{
	int i,j;
	for(i=1;i<=200;i++)
	{
		for(j=2;j<i;j++)
		{
		if((i%j==0))
		{
			break;
		}}
		if(i==j)
		{
			printf(" %d ",i);
		}}}
		
	

