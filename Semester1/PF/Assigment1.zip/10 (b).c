// ASSIGNMENT=1
//  SE-SEC 2A
// ID=20K-1044
// MUHAMMAD AYAZ

#include<stdio.h>
int main()
{
	int i;
	for(i=20;i>=-10;i=i-6)
	{
		printf(" %d ",i);
	}
}
