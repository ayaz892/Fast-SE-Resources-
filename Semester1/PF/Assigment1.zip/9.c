// ASSIGNMENT=1
//  SE-SEC 2A
// ID=20K-1044
// MUHAMMAD AYAZ

#include <stdio.h>

int main()

{
	
	char alp;
	
	int i;
	
	for(i=0;i<5;i++)
	{
		
		scanf("%c",&alp);
	}
	
	for(i=0;i<5;i++)
	{
		
		printf("%c",alp-32);
}
}

