// ASSIGNMENT=1
//  SE-SEC 2A
// ID=20K-1044
// MUHAMMAD AYAZ


#include <stdio.h>
int main()
{
	int num,i=1,avg,total=0;
	for(num>0;;num++)
	{
		
		scanf("%d",&num);
		i++;
		total=total+num;
		if(num==9999)
		
		break;
	}
	avg=total/i;
	printf("avg is:%d",avg);
} 
