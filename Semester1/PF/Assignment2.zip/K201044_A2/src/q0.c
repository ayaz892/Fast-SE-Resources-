#include <stdio.h>

int main() {
    // already solved :)
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        printf("%d\n", x*2);
    }
    return 0;
}
