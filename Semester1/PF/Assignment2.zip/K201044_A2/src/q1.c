#include <stdio.h>

#define N 50


int main() {
    int arr[N];
    int n;

    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // TODO: SOLVE
}
