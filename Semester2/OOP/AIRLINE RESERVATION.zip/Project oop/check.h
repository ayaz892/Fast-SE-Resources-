#include <iostream>
using namespace std;

int checkpayment(int x)
{
	float ap;
   switch (x)
   {
   	case 1:
   		ap = 1200.00;
   		break;
   	case 2:
   		ap = 3550.00;
   		break;
   	case 3:
   		ap = 2450.00;
   		break;
   	case 4:
   		ap = 2570.00;
   		break;
   	case 5:
   		ap = 3470.00;
   		break;
   	case 6:
   		ap = 4000.00;
   		break;
   	case 7:
   		ap = 1000.00;
   		break;
   	case 8:
   		ap = 3250.00;
   		break;
   	case 9:
   		ap = 2250.00;
   		break;
   	case 10:
   		ap = 3175.00;
   		break;
   	case 11:
   		break;
   }
   return ap;
}



































